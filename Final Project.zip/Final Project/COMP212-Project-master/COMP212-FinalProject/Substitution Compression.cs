﻿
/*  ----------------------------------------
 * 
 *  COMP 212 - Programming 3                
 *  Final Project - Substitute Compression
 *  Submission date: 17/08/2016
 *  ----------------------------------------
 *  Selina Daley
 *  Amna Gulraiz - 300627536
 *  Kevin 
 *  Max
 *  Kadim 
 *  ----------------------------------------
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMP212_FinalProject
{
    public partial class FrmSubstitutionCompression : Form
    {
         //Create Dictionaries
            Dictionary<char, int> ASCII = new Dictionary<char, int>();
            Dictionary<char, int> Occurrence = new Dictionary<char, int>();
            Dictionary<char, double> Frequency = new Dictionary<char, double>();
            Dictionary<char, double> Sorted_Frequency = new Dictionary<char, double>();
            Dictionary<char, string> Huffman_Code = new Dictionary<char, string>();

            //Create a list to hold the huffman values and populate the list
            List<string> HuffmanValues = new List<string>();

            //Instance variables
            string fileName = "IronHeel.txt", fileName2 = "encrypt.txt"; //Hardcoded textfile
            FileStream inFile, newFile;
            StreamReader reader;
            StreamWriter writer;
            string nextRecord; 
            bool done = false;
            int count = 0, count2 = 0;
            double count3 = 0, count4 = 0;
            int startValue = 1;
        public FrmSubstitutionCompression()
        {
            InitializeComponent();
            PopulateHuffmanList(HuffmanValues);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            //browse button functionality --- OpenFile Dialog opens the location of the file

              OpenFileDialog dlg = new OpenFileDialog();
              dlg.InitialDirectory = "C:\\Users\\COMP212-Project\\COMP212-FinalProject\\bin\\Debug\\IronHeel.txt";
              dlg.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
              if (dlg.ShowDialog() == DialogResult.OK)
              {
                  txtFileName.Text = Path.GetFileName(dlg.FileName);
              }

        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
           
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

           public static void PopulateHuffmanList(List<string> huffmanList)
        {
            huffmanList.Add("100");
            huffmanList.Add("0010");
            huffmanList.Add("0011");
            huffmanList.Add("1111");
            huffmanList.Add("1110");//5
            huffmanList.Add("1100");
            huffmanList.Add("1011");
            huffmanList.Add("1010");
            huffmanList.Add("0110");
            huffmanList.Add("0101");//10
            huffmanList.Add("11011");
            huffmanList.Add("01111");
            huffmanList.Add("01001");
            huffmanList.Add("01000");
            huffmanList.Add("00011");//15
            huffmanList.Add("00010");
            huffmanList.Add("00001");
            huffmanList.Add("00000");
            huffmanList.Add("110101");
            huffmanList.Add("011101");//20
            huffmanList.Add("011100");
            huffmanList.Add("1101001");
            huffmanList.Add("110100011");
            huffmanList.Add("110100001");
            huffmanList.Add("110100000");//25
            huffmanList.Add("1101000101");
            huffmanList.Add("1101000100");
        }

           private void FrmSubstitutionCompression_Load(object sender, EventArgs e)
           {
               List<TextBox> list = new List<TextBox>();
               for (int i = 0; i < 28; i++)
               {
                   list.Add(new TextBox());
                   list[i].Name = i.ToString();
                   list[i].Location = new System.Drawing.Point(40, (i * 20) + 60);
                   list[i].ReadOnly = true;
                   list[i].TextAlign = HorizontalAlignment.Center;
                   this.Controls.Add(list[i]);
               }
               list[0].Text = "Letter";
               list[1].Text = "Space";
               list[2].Text = "A";
               list[3].Text = "B";
               list[4].Text = "C";
               list[5].Text = "D";
               list[6].Text = "E";
               list[7].Text = "F";
               list[8].Text = "G";
               list[9].Text = "H";
               list[10].Text = "I";
               list[11].Text = "J";
               list[12].Text = "K";
               list[13].Text = "L";
               list[14].Text = "M";
               list[15].Text = "N";
               list[16].Text = "O";
               list[17].Text = "P";
               list[18].Text = "Q";
               list[19].Text = "R";
               list[20].Text = "S";
               list[21].Text = "T";
               list[22].Text = "U";
               list[23].Text = "V";
               list[24].Text = "W";
               list[25].Text = "X";
               list[26].Text = "Y";
               list[27].Text = "Z";
               
               List<TextBox> list2 = new List<TextBox>();
               for (int i = 0; i < 27; i++)
               {
                   list2.Add(new TextBox());
                   list[i].Name = (i + 28).ToString();
                   list2[i].Location = new System.Drawing.Point(140, (i * 20) + 80);
                   this.Controls.Add(list2[i]);
                   list2[i].TextAlign = HorizontalAlignment.Center;
               }

               List<TextBox> list3 = new List<TextBox>();
               for (int i = 0; i < 27; i++)
               {
                   list3.Add(new TextBox());
                   list3[i].Location = new System.Drawing.Point(240, (i * 20) + 80);
                   this.Controls.Add(list3[i]);
                   list3[i].TextAlign = HorizontalAlignment.Center;
               }

               List<TextBox> list4 = new List<TextBox>();
               for (int i = 0; i < 27; i++)
               {
                   list4.Add(new TextBox());
                   list4[i].Location = new System.Drawing.Point(340, (i * 20) + 80);
                   this.Controls.Add(list4[i]);
                   list4[i].TextAlign = HorizontalAlignment.Center;
               }

               List<TextBox> list5 = new List<TextBox>();
               for (int i = 0; i < 27; i++)
               {
                   list5.Add(new TextBox());
                   list5[i].Location = new System.Drawing.Point(440, (i * 20) + 80);
                   this.Controls.Add(list5[i]);
                   list5[i].TextAlign = HorizontalAlignment.Center;
               }
               List<TextBox> list6 = new List<TextBox>();
               for (int i = 0; i < 4; i++)
               {
                   list6.Add(new TextBox());
                   list6[i].ReadOnly = true;
                   list6[i].Location = new System.Drawing.Point(140 + (i * 100), 60);
                   this.Controls.Add(list6[i]);
                   list6[i].TextAlign = HorizontalAlignment.Center;
               }
               list6[0].Text = "Ascii";
               list6[1].Text = "Occurence";
               list6[2].Text = "Frequency";
               list6[3].Text = "Huffman_Code";
           }
    }
}
